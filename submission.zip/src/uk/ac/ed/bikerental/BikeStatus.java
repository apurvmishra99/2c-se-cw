package uk.ac.ed.bikerental;

enum BikeStatus {
    AVAILABLE, DELIVERY, ONLOAN, REPAIR, WRITTENOFF;
}