package uk.ac.ed.bikerental;

enum CurrentAction {
    REGISTER, VIEW, BOOK, EMPLOYEE, RETURN, CHANGE;
}