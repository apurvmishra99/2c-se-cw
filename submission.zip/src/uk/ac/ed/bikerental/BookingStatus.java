package uk.ac.ed.bikerental;

enum BookingStatus {
    BOOKED, ONLOAN, RETURNED;
}