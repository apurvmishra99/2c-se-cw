package uk.ac.ed.bikerental;

enum PickupMethod {
    DELIVERY, PICKUP;
}